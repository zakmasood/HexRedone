var searchData=
[
  ['category_0',['Category',['../class_building_data.html#af2281cf7d3a4a23225a8ec4aa0e3b0d5',1,'BuildingData']]],
  ['color_1',['Color',['../class_building_data.html#afa3b5401c9cd52e0a98e4a424a6a3658',1,'BuildingData']]]
];
