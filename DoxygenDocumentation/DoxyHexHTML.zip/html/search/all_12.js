var searchData=
[
  ['updateresourcetype_0',['UpdateResourceType',['../class_tile_data.html#a4c7ea56de9bb637ad2ce2d21e3d3b9c0',1,'TileData']]]
];
