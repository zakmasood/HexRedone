var searchData=
[
  ['buildings_0',['Buildings',['../class_buildings_list.html#a4fa839469852773f75c01da9d8158722',1,'BuildingsList']]],
  ['buildingtype_1',['BuildingType',['../class_building_data.html#aac495d76f83a7709cac223ae3fe181fe',1,'BuildingData']]]
];
