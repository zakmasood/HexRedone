var searchData=
[
  ['tileid_0',['TileID',['../class_tile_data.html#ad475be77f9e449b7309c40becc4e0b8c',1,'TileData']]],
  ['totalbuildingscount_1',['TotalBuildingsCount',['../class_quest.html#ab4b708515bd2e30991ca13d90c092ac5',1,'Quest']]]
];
