var searchData=
[
  ['icon_0',['Icon',['../class_building_data.html#a15b9f7868651238b4656c035aa611964',1,'BuildingData']]],
  ['id_1',['Id',['../class_quest.html#a16895e35788fc525ce5db489264764b9',1,'Quest']]],
  ['iscompleted_2',['IsCompleted',['../class_quest.html#a571b9ac9728e3fe099fef9f5b3c9b7ef',1,'Quest']]],
  ['itemneeded_3',['ItemNeeded',['../class_building_data.html#a3a41fdfd2eff461210b9d55314744845',1,'BuildingData']]]
];
