var searchData=
[
  ['gridlength_0',['gridLength',['../class_world_gen.html#a02318f6cc691bedae4e80b5a0d6a5610',1,'WorldGen']]],
  ['gridwidth_1',['gridWidth',['../class_world_gen.html#af05a3818627a4641daf7d0663dccd824',1,'WorldGen']]]
];
