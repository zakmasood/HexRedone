var searchData=
[
  ['previousresourcetype_0',['previousResourceType',['../class_tile_data.html#af696937cadf42a039904600690debdfb',1,'TileData']]]
];
