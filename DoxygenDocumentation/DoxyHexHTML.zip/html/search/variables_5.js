var searchData=
[
  ['infotext_0',['infoText',['../class_player_controller.html#abfb56e956a20864bdda7b6d8d4b4e422',1,'PlayerController.infoText'],['../class_tile_info_display.html#a5d685b96c7715fa58386761e6b6c5798',1,'TileInfoDisplay.infoText']]],
  ['itemneeded_1',['itemNeeded',['../class_building_taxonomy.html#a2c9b6dc0743bb3aa4e001ada77513bad',1,'BuildingTaxonomy']]]
];
