var searchData=
[
  ['tiledata_0',['TileData',['../class_tile_data.html#af22f643b5f68e76e40f857622f6fafcf',1,'TileData.TileData()'],['../class_tile_data.html#a4a54a3f85577465254ec926cba85dbce',1,'TileData.TileData(int tileID, int x, int z, string resourceType, string previousResourceType)']]]
];
