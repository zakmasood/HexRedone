var searchData=
[
  ['nextscenename_0',['nextSceneName',['../class_splash_manager.html#ac22acb59045af6a234c73d616c2ed9bb',1,'SplashManager']]]
];
